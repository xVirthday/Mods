package net.minecraft.storagebox;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;

import org.lwjgl.opengl.GL11;

public class GuiStorage extends GuiContainer
{
	private static final ResourceLocation _rl = new ResourceLocation("storagebox:textures/item/ItemSelect.png");
    public GuiStorage(ItemStack itemstack, InventoryPlayer inventoryplayer, World world)
    {
        super(new ContainerStorage(itemstack, inventoryplayer, world));
    }

    @Override
    public void onGuiClosed()
    {
        super.onGuiClosed();
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int par1, int par2)
    {
    	fontRenderer.drawString("Storage", 8, 20, 0x404040);
    	fontRenderer.drawString("Inventory", 8, (ySize - 96) + 2, 0x404040);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float f, int i, int j)
    {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        mc.getTextureManager().bindTexture(_rl);
        int l = (width - xSize) / 2;
        int i1 = (height - ySize) / 2;
        drawTexturedModalRect(l, i1, 0, 0, xSize, ySize);
    }
}
