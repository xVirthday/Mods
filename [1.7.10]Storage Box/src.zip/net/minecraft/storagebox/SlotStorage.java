package net.minecraft.storagebox;

import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class SlotStorage extends Slot {
	public SlotStorage(IInventory iinventory1, int i, int j, int k) {
		super(iinventory1, i, j, k);
	}

	@Override
	public boolean isItemValid(ItemStack itemstack) {
		// StorageBoxは不可
		if (itemstack.getItem() instanceof ItemStorageBox) {
			return false;
		}

		// 情報を保持している場合不可
		if (itemstack.hasTagCompound()) {
			return false;
		}

		// Tool系は不可
		if (itemstack.getItem().isDamageable()) {
			return false;
		}

		// エンチャ可能アイテムは不可
		if (itemstack.isItemEnchanted()) {
			return false;
		}

		return true;
	}
}
