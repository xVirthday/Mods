package net.minecraft.storagebox;

import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.crafting.ShapelessRecipes;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;

public class AutoCollectRecipes extends ShapelessRecipes
{
    public AutoCollectRecipes(ItemStack storagebox)
    {
        super("", storagebox, getRecipeList(storagebox));
    }

    @Override
    public boolean matches(InventoryCrafting par1InventoryCrafting, World world)
    {
        return super.matches(par1InventoryCrafting, world);
    }

    @Override
    public ItemStack getCraftingResult(InventoryCrafting inventorycrafting)
    {
        ItemStack result = null;

        for (int i = 0; i < 3 ; i++)
        {
            for (int j = 0; j < 3 ; j++)
            {
                ItemStack itemstack = inventorycrafting.getStackInRowAndColumn(i, j);

                if (itemstack == null)
                {
                    continue;
                }

                if (itemstack.getItem() != mod_StorageBox.itemStBox)
                {
                    continue;
                }

                result = itemstack.copy();
                ItemStorageBox.changeAutoCollect(result);
                break;
            }
        }

        return result;
    }

	private static NonNullList<Ingredient> getRecipeList(ItemStack stackStorage) {
		final NonNullList<Ingredient> list = NonNullList.create();
		list.add(Ingredient.fromStacks(stackStorage.copy()));
		return list;
	}
}
