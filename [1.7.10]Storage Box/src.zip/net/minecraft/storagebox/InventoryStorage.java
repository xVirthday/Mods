package net.minecraft.storagebox;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;

public class InventoryStorage implements IInventory {
	private ItemStack[] stackResult;
	private ItemStack sitemstack;
	private InventoryPlayer inventoryplayer;

	public InventoryStorage(ItemStack itemstack, InventoryPlayer inventoryplayer, World world) {
		stackResult = new ItemStack[] { ItemStack.EMPTY };
		sitemstack = itemstack;
		this.inventoryplayer = inventoryplayer;
	}

	@Override
	public int getSizeInventory() {
		return 1;
	}

	@Override
	public ItemStack getStackInSlot(int i) {
		return stackResult[i];
	}

    public String getInvName()
    {
        return "Storage";
    }

	@Override
	public ItemStack decrStackSize(int i, int j) {
		if (stackResult[i] != null && !stackResult[i].isEmpty()) {
			ItemStack itemstack = stackResult[i];
			stackResult[i] = ItemStack.EMPTY;
			return itemstack;
		} else {
			return ItemStack.EMPTY;
		}
	}

	@Override
	public void setInventorySlotContents(int i, ItemStack itemstack) {
		stackResult[i] = null == itemstack ? ItemStack.EMPTY : itemstack;
	}

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
    public boolean isUsableByPlayer(EntityPlayer entityplayer)
    {
        return true;
    }

	private void save() {
		ItemStack itemstack = stackResult[0];
		ItemStorageBox.setItemStack(sitemstack, itemstack);
		if (inventoryplayer.offHandInventory.get(0) == sitemstack) {
			net.minecraftforge.fml.common.FMLLog.log.info("InventoryStorageBox.save={}, {}(offhand)", sitemstack.toString(), itemstack.toString());
			inventoryplayer.offHandInventory.set(0, sitemstack);
		} else {
			net.minecraftforge.fml.common.FMLLog.log.info("InventoryStorageBox.save={}, {}(currentItem={})", sitemstack.toString(), itemstack.toString(), inventoryplayer.currentItem);
			inventoryplayer.mainInventory.set(inventoryplayer.currentItem, sitemstack);
		}
	}

	@Override
	public ItemStack removeStackFromSlot(int var1) {
		if (stackResult[var1] != null && !stackResult[var1].isEmpty()) {
			ItemStack itemstack = stackResult[var1];
			stackResult[var1] = ItemStack.EMPTY;
			return itemstack;
		} else {
			return ItemStack.EMPTY;
		}
	}

	@Override
	public boolean isItemValidForSlot(int i, ItemStack itemstack) {
		return true;
	}

	@Override
	public void markDirty() {
        save();
	}

	@Override
	public boolean hasCustomName() {
		return false;
	}

	@Override
	public ITextComponent getDisplayName() {
		return this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName(), new Object[0]);
	}

	@Override
	public void openInventory(EntityPlayer player) {
	}

	@Override
	public void closeInventory(EntityPlayer player) {
		save();
	}

	@Override
	public int getField(int id) {
		return 0;
	}

	@Override
	public void setField(int id, int value) {
	}

	@Override
	public int getFieldCount() {
		return 0;
	}

	@Override
	public void clear() {
	}

	@Override
	public String getName() {
		return "container.StorageBox";
	}

	@Override
	public boolean isEmpty() {
		if (null == stackResult || null == stackResult[0]) {
			return true;
		}
		return stackResult[0].isEmpty();
	}
}
