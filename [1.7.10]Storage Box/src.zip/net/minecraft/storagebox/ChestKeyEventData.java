package net.minecraft.storagebox;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ChestKeyEventData {
	public boolean isShift = false;
	public boolean isCtrl = false;
	public int windowID = 0;
	public void read(byte[] b) {
		DataInputStream in = new DataInputStream(new ByteArrayInputStream(b));
		try {
			in.readByte();	// 読み捨てる。
			this.isShift = in.readBoolean();
			this.isCtrl = in.readBoolean();
			this.windowID = in.readInt();
		} catch (IOException e) {
		}
	}
	public byte[] write() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream os = new DataOutputStream(baos);
		try {
			os.writeByte(mod_StorageBox.CHANNEL_FLAG_GUI);
			os.writeBoolean(this.isShift);
			os.writeBoolean(this.isCtrl);
			os.writeInt(this.windowID);
		} catch (IOException e) {
		} finally {
			try {
				os.close();
			} catch (IOException e) {
			}
		}
		return baos.toByteArray();
	}
}
