package net.minecraft.storagebox;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import org.apache.logging.log4j.Level;

import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.common.config.Property;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.relauncher.Side;

public class ModConfig {
	private static Class<?> _cls = null;
	private static File _file = null;
	private static long _lastModify = 0;
	private static long _lastCheck = 0;
	private static final long _checkInterval = 5L * 1000;
	public static void configure(final Class<?> cls, FMLPreInitializationEvent event) {
		_cls = cls;
		_file = event.getSuggestedConfigurationFile();
		execConfigure();
	}
	public static boolean checkAndReload() {
		long n = System.currentTimeMillis() - _lastCheck;
		if (n < _checkInterval) {
			return false;
		}
		if (!_file.isFile()) {
			return false;
		}
		if (_lastModify == _file.lastModified()) {
			return false;
		}
		execConfigure();
		_lastCheck = System.currentTimeMillis();
		// 再読み込みしたことを通知。
		String s = String.format("%s config reload.", _cls.getName());
		if (Side.CLIENT.equals(FMLCommonHandler.instance().getSide())) {
			final net.minecraft.client.Minecraft minecraft = net.minecraftforge.fml.client.FMLClientHandler.instance().getClient();
			if (null != minecraft) {
				minecraft.ingameGUI.getChatGUI().printChatMessage(new TextComponentString(s));
			}
		} else {
			net.minecraftforge.fml.common.FMLLog.log.info(s);
		}
		return true;
	}
	private static void execConfigure() {
		boolean isSave = !_file.isFile() || _file.length() <= 0;
		Configuration config = new Configuration(_file);
		config.load();
		if (!config.hasCategory(Configuration.CATEGORY_GENERAL)) {
			isSave = true;
		}
		final Field[] fields = _cls.getFields();
		for (Field f : fields) {
			final ModProperty anno = f.getAnnotation(ModProperty.class);
			if (null == anno) {
				continue;
			}
			if (!Modifier.isStatic(f.getModifiers())) {
				continue;
			}
			final Class<?> type = f.getType();
			try {
				Property p = null;
				String comment = null;
				if (type.equals(Boolean.TYPE)) {
					p = config.get(Configuration.CATEGORY_GENERAL, f.getName(), f.getBoolean(null));
					comment = "Boolean: " + (f.getBoolean(null) ? "true" : "false");
					f.setBoolean(null, p.getBoolean(f.getBoolean(null)));
				} else if (type.equals(Integer.TYPE)) {
					p = config.get(Configuration.CATEGORY_GENERAL, f.getName(), f.getInt(null));
					comment = "Integer: " + f.getInt(null);
					f.setInt(null, p.getInt());
				} else if (type.equals(Double.TYPE)) {
					p = config.get(Configuration.CATEGORY_GENERAL, f.getName(), f.getDouble(null));
					comment = "Double: " + f.getDouble(null);
					f.setDouble(null, p.getDouble(0));
				} else if (type.equals(String.class)) {
					p = config.get(Configuration.CATEGORY_GENERAL, f.getName(), f.get(null).toString());
					comment = "String: \"" + f.get(null) + '"';
					f.set(null, p.getString());
				} else {
					net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "unrecognizable type: %s", type.getCanonicalName());
				}
				if (null != anno.comment() && anno.comment().length() >= 1) {
					if (null == comment) {
						comment = anno.comment();
					} else {
						comment += "\n" + anno.comment();
					}
				}
				if (null != p && null != comment) {
					p.setComment(comment);
				}
			} catch (IllegalArgumentException e) {
			} catch (IllegalAccessException e) {
			}
		}
		if (isSave) {
			config.save();
		}
		_lastModify = _file.lastModified();
		_lastCheck = System.currentTimeMillis();
	}

	public static int getKeyboardNo(String name) {
		if (FMLCommonHandler.instance().getSide() != Side.CLIENT) {
			return -1;
		}
		Field[] fs = null;
		try {
			Class<?> cls = Class.forName("org.lwjgl.input.Keyboard");
			fs = cls.getFields();
		} catch (ClassNotFoundException e1) {
			return -1;
		}
		if (null == fs) {
			return -1;
		}
		int key_no = 0;
		for (Field f : fs) {
			if (!Modifier.isStatic(f.getModifiers())) {
				continue;
			}
			String s = f.getName();
			if (0 != s.indexOf("KEY_")) {
				continue;
			}
			if (s.equalsIgnoreCase(name)) {
				try {
					key_no = f.getInt(null);
				} catch (IllegalArgumentException e) {
				} catch (IllegalAccessException e) {
				}
				break;
			}
		}
		net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "getKeyboardNo=%d", key_no);
		return key_no;
	}
}
