package net.minecraft.storagebox;


import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Keyboard;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;
import net.minecraftforge.fml.common.network.FMLEventChannel;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ServerCustomPacketEvent;
import net.minecraftforge.fml.common.network.IGuiHandler;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.registries.IForgeRegistry;

/**
 * （ほぼ）無限に同一アイテムが収納できるストレージボックスを追加する。
 * 作成：チェストをかまど作成と同一に８個ならべる。
 * 機能：空の StorageBox を手に持って L キーを押すと収納対象のアイテムを指定する GUI が出る。
 * 指定されたアイテムを収納する場合は、StorageBox を手にして L キー。
 * 自動収納機能付きの場合はアイテムを拾った時に自動収納する。
 * 自動収納を止めたい場合は StorageBox そのものをクラフトすれば機能が On/Off トグルする。
 *
 * チェストからの取り出しは StorageBox を手に持った状態で
 * チェストを開いて : キー。チェストへの格納は同様に Shift＋: キー。
 * Shift+Ctrl+: で１スタックずつチェストへ格納。
 * 未定：Ctrl+: キー
 *
 * @author Unyuho
 * @author scalar
 *
 */
@Mod(modid = mod_StorageBox.MOD_ID, name = mod_StorageBox.MOD_NAME, version = mod_StorageBox.VERSION)
@Mod.EventBusSubscriber(modid = mod_StorageBox.MOD_ID)
public class mod_StorageBox implements IGuiHandler {
	public static final String MOD_NAME = "StorageBox";
	public static final String MOD_ID = "storagebox";
	public static final String VERSION = "3.1.9";

	//@MLProp(min = 5000, max = 32000)
//	@ModProperty
//	public static int itemID = 28810;
	//@MLProp(info = "StorageKey")
	@ModProperty
	public static String keyCode = "KEY_SEMICOLON";
	@ModProperty
	public static int containerID = 21;
	@ModProperty
	public static boolean AddName = false;
	@ModProperty
	public static boolean AddCount = false;
	@ModProperty
	public static boolean AutoCollect = true;
	@ModProperty
	public static int Position = 0;
	//@MLProp(min = 0, max = 0xFFFFFF)
	@ModProperty
	public static int Color = 0xFFFFFF;
	@ModProperty(comment = "find StorageBox in ender chest item in plyaer's inventory.")
	public static boolean exploreEnderChest = false;

	public static ItemStorageBox itemStBox;
	protected static final int largeChestSlotNum = 9 * 6;

	//private static String KeyStorage = "StorageBox StorageKey";
	private static final String CHANNEL_NAME = "mod_StorageBox";
	protected static final int CHANNEL_FLAG_KEY = 0;
	protected static final int CHANNEL_FLAG_GUI = 1;

	//private GuiScreen tickInGui;
	private boolean isSneaking;
	private Block blockID = null;
	private BlockPos blockPos = null;
	private int _key_no = 0;
	private boolean _keyPressed = false;
	protected static mod_StorageBox _instance = null;

	private void reloadConfigData() {
		_key_no = ModConfig.getKeyboardNo(keyCode);
		Position = -1 * Position;
	}

	@SubscribeEvent
	public static void registerItems(final RegistryEvent.Register<Item> event) {
		final IForgeRegistry<Item> registry = event.getRegistry();
		registry.register(itemStBox);
	}
	@SubscribeEvent
	public static void registerRecipes(final RegistryEvent.Register<IRecipe> event) {
		final IForgeRegistry<IRecipe> registry = event.getRegistry();
		IRecipe r = new AutoCollectRecipes(new ItemStack(itemStBox, 1, -1));
		r.setRegistryName(new ResourceLocation(itemStBox.getRegistryName().getResourceDomain(), itemStBox.getRegistryName().getResourcePath() + '_'));
		registry.register(r);
	}

	@EventHandler
	public void preInit(FMLPreInitializationEvent event) {
		_instance = this;
		ModConfig.configure(this.getClass(), event);
		reloadConfigData();

		itemStBox = new ItemStorageBox();
		itemStBox.setUnlocalizedName("storagebox");
		itemStBox.setCreativeTab(CreativeTabs.MISC);
		itemStBox.setRegistryName("storagebox");

		if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
			preInitClient();
		}
	}
	@EventHandler
	public void init(FMLInitializationEvent event) {
/* Forge不要
		//染色
		ItemStack anyStorageBox = new ItemStack(itemStBox, 1, -1);
		ItemStack dye = null;
		List Recipe = CraftingManager.getInstance().getRecipeList();
		for (int k = 0; k < itemStBox.Colors.length; k++) {
			dye = new ItemStack(Item.dyePowder, 1, 15-k);
			Recipe.add(new StorageRecipes(new ItemStack(itemStBox, 1, k),anyStorageBox, dye));
		}
*/
		//ModLoader.setInGUIHook(this, true, false);
		if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
			initClient();
//		} else if (FMLCommonHandler.instance().getSide() == Side.SERVER) {
		}
		if (AutoCollect) {
			MinecraftForge.EVENT_BUS.register(new EventHooks());
		}
		NetworkRegistry.INSTANCE.registerGuiHandler(this, this);
		FMLEventChannel e = NetworkRegistry.INSTANCE.newEventDrivenChannel(CHANNEL_NAME);
		e.register(this);
	}
	/**
	 * クライアント側初期化。こうやって分離しないとなぜかサーバ側でクライアント関連クラスを
	 * 呼びだそうとしてしまうので隔離。
	 */
	@SideOnly(Side.CLIENT)
	private void preInitClient() {
		MinecraftForge.EVENT_BUS.register(this);
		MinecraftForge.EVENT_BUS.register(new EventModelBake());
		//MinecraftForgeClient.registerItemRenderer(itemStBox, new StorageRenderer());
	}
	/**
	 * クライアント側初期化。こうやって分離しないとなぜかサーバ側でクライアント関連クラスを
	 * 呼びだそうとしてしまうので隔離。
	 */
	@SideOnly(Side.CLIENT)
	private void initClient() {
		FMLClientHandler.instance().getClient().getRenderItem().getItemModelMesher().register(itemStBox, new ItemMeshDefinitionStorageBox());
	}

	@SubscribeEvent
	public void onServerPacket(ServerCustomPacketEvent event) {
		final EntityPlayer player = ((NetHandlerPlayServer)event.getHandler()).player;
		final ByteBuf bbPayload = event.getPacket().payload();
		final byte[] data = new byte[bbPayload.capacity()];
		bbPayload.getBytes(0, data);
		final int flag = data[0];
		if (ModConfig.checkAndReload()) {
			reloadConfigData();
		}
		if (CHANNEL_FLAG_KEY == flag) {
			final boolean isSneaking = (data[1] == 0);
			itemStBox.keyboardEvent(isSneaking, player);
		} else if (CHANNEL_FLAG_GUI == flag) {
			ChestKeyEventData d = new ChestKeyEventData();
			d.read(data);
			if (null != player && null != player.inventory
					&& null != player.inventory.getItemStack()
					&& player.inventory.getItemStack().getItem() instanceof ItemStorageBox
					) {
				// GUI を開いていて、手に StorageBox を持っている
				if (null == ItemStorageBox.getItem(player.inventory.getItemStack())) {
					// 空っぽの StorageBox の場合は無視。
					return;
				}
				if (d.isCtrl && d.isShift) {
					// Shift+Ctrl+L を押下した。
					itemStBox.dropCurrentItem(player.inventory.getItemStack(), player);
				} else if (!d.isCtrl && !d.isShift) {
					// L のみ押下した。
					itemStBox.storageCurrentItem(player.inventory.getItemStack(), player);
				}
				return;
			}
			Container container = player.openContainer;
			if (null != container && container.windowId == d.windowID) {
			} else {
				return;
			}
			@SuppressWarnings("rawtypes")
			List list = container.inventorySlots;
			ItemStack itemstack = player.getHeldItemMainhand();

			// 各種動作
			if (d.isShift) {
				// チェストへ収納
				itemStBox.dropToChest(itemstack, list, d.isCtrl);
			} else {
				// チェストから取出
				itemStBox.storageFromChest(player, itemstack, list);
			}
		}
	}

	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		//cpw.mods.fml.common.FMLLog.info("mod_StorageBox.getServerGuiElement=%d", ID);
		if (containerID == ID) {
			return new ContainerStorage(-1 == x ? player.inventory.offHandInventory.get(0) : player.getHeldItemMainhand(), player.inventory, world);
		}
		return null;
	}
	@Override
	@SideOnly(Side.CLIENT)
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		//cpw.mods.fml.common.FMLLog.info("mod_StorageBox.getClientGuiElement=%d", ID);
		if (containerID == ID) {
			return new GuiStorage(-1 == x ? player.inventory.offHandInventory.get(0) : player.getHeldItemMainhand(), player.inventory, world);
		}
		return null;
	}

	@SideOnly(Side.CLIENT)
	@SubscribeEvent
	public void tickEvent(ClientTickEvent event) {
		if (!TickEvent.Phase.END.equals(event.phase)) {
			return;
		}
		if (ModConfig.checkAndReload()) {
			reloadConfigData();
		}
		if (!_keyPressed && Keyboard.isKeyDown(_key_no)) {
			_keyPressed = true;
		} else {
			_keyPressed = false;
		}
		if (_keyPressed) {
			inputKeyEvent();
		}
		final Minecraft minecraft = FMLClientHandler.instance().getClient();
		if (minecraft.currentScreen != null) {
			return;
		}

		EntityPlayer entityplayer = minecraft.player;
		isSneaking = entityplayer.isSneaking();

		// onTickInGUIでの直前のブロック判定用
		if (minecraft.objectMouseOver != null
				&& minecraft.objectMouseOver.typeOfHit == Type.BLOCK) {
			blockPos = minecraft.objectMouseOver.getBlockPos();
			blockID = minecraft.world.getBlockState(blockPos).getBlock();
		} else {
			blockID = null;
		}
	}

	@SideOnly(Side.CLIENT)
	@SubscribeEvent
	public void tickEvent(RenderTickEvent event) {
		if (!TickEvent.Phase.END.equals(event.phase)) {
			return;
		}
		final Minecraft minecraft = FMLClientHandler.instance().getClient();
		final EntityPlayer entityplayer = minecraft.player;
		if (entityplayer == null) {
			return;
		}

		// アイテム情報表示
		ItemStack CurrentStack = entityplayer.inventory.getCurrentItem();
		if (CurrentStack != null) {
			Item CurrentItem = CurrentStack.getItem();

			if (CurrentItem instanceof ItemStorageBox) {
				itemStBox.displayItemInfo(CurrentStack);
			}
		}
/*
		GuiScreen guiscreen = minecraft.currentScreen;
		if (tickInGui == guiscreen) {
			return;
		}

		tickInGui = guiscreen;

		if (!(guiscreen instanceof GuiContainer)) {
			return;
		}

		// 手持ちアイテムの確認
		ItemStack itemstack = entityplayer.getCurrentEquippedItem();
		if (itemstack == null || itemstack.getItem() != itemStBox) {
			return;
		}

		// IInventoryの実装確認
		if (null == blockID || Blocks.air == blockID) {
			return;
		}

		Block block = blockID;

		if (!(block instanceof BlockContainer)) {
			return;
		}

		TileEntity tileentity = minecraft.world.getTileEntity(blockPos);

		if (!(tileentity instanceof IInventory)) {
			return;
		}
//*/
		/*
		GuiContainer gui = (GuiContainer)guiscreen
		List list = gui.inventorySlots.inventorySlots;

		//各種動作
		if (isSneaking) { //チェストへ収納
			itemStBox.dropToChest(itemstack, list);
		} else { //チェストから取出
			itemStBox.storageFromChest(itemstack, list);
		}
		*/
/*
		byte[] data = new byte[] {
				CHANNEL_FLAG_KEY,
				(byte) (entityplayer.isSneaking() ? 0 : 1),
		};
		minecraft.getNetHandler().addToSendQueue(new C17PacketCustomPayload(CHANNEL_NAME,
				toPacketBuffer(data)));
//*/
		//FMLLog.info("mod_StorageBox.RenderTickEvent");
	}

	@SideOnly(Side.CLIENT)
	public void inputKeyEvent() {
		//cpw.mods.fml.common.FMLLog.info("inputKey");
		final Minecraft minecraft = FMLClientHandler.instance().getClient();
		// itemStBox.keyboardEvent(isSneaking);
		isSneaking = Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
		final boolean isCtrl = Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL);
		// パケット準備。
		ChestKeyEventData d = new ChestKeyEventData();
		d.isShift = isSneaking;
		d.isCtrl = isCtrl;
		do {
			if (null == minecraft.currentScreen) {
				d = null;
				break;
			}
/*
			if (minecraft.currentScreen instanceof GuiChest) {
			} else {
				return;
			}
*/
			if (minecraft.currentScreen instanceof GuiStorage) {
				return;
			}
			if (!(minecraft.currentScreen instanceof GuiContainer)) {
				return;
			}
/*
			if (null != minecraft.player && null != minecraft.player.inventory) {
				final ItemStack handledItemStack = minecraft.player.inventory.getItemStack();
				if (null != handledItemStack && handledItemStack.getItem() instanceof ItemStorageBox) {
					// L 押下、かつ手に StorageBox を持っている。
					break;
				}
			}
*/
			if (minecraft.currentScreen instanceof GuiInventory) {
				d = null;
				break;
			}
			// IInventoryの実装確認
			if (blockID == null || !(blockID instanceof BlockContainer)) {
				return;
			}
			TileEntity tileentity = minecraft.world.getTileEntity(blockPos);
			if (!(tileentity instanceof IInventory)) {
				return;
			}
			ItemStack CurrentStack = minecraft.player.inventory.getCurrentItem();
			if (null != CurrentStack && CurrentStack.getItem() instanceof ItemStorageBox) {
			} else {
				return;
			}
			// チェストを開いている。
			d.windowID = ((GuiContainer)minecraft.currentScreen).inventorySlots.windowId;
		} while(false);
		if (null != d) {
			minecraft.getConnection().sendPacket(new CPacketCustomPayload(CHANNEL_NAME, toPacketBuffer(d.write())));
			return;
		}

		byte[] data = new byte[] {
				CHANNEL_FLAG_KEY,
				(byte) (isSneaking ? 0 : 1),
		};

		minecraft.getConnection().sendPacket(new CPacketCustomPayload(CHANNEL_NAME, toPacketBuffer(data)));
	}
	private static PacketBuffer toPacketBuffer(byte[] b) {
		return new PacketBuffer(Unpooled.wrappedBuffer(b));
	}

	/**
	 * 指定クラスのフィールドをすべて得る
	 *
	 * @param insClass
	 *            フィールドを取り出す対象のクラス。
	 * @param instance
	 *            フィールドを取り出す対象のクラスのインスタンス。static フィールドを得る場合は null にする。
	 * @param targetClass
	 *            取り出したいフィールドの型。一致するフィールドがすべて取り出される。
	 * @return 取り出したフィールド
	 */
	public static List<Field> findFields(Class<?> insClass, Object instance, Class<?> targetClass) {
		final List<Field> ret = new ArrayList<>();
		if (null == insClass && null != instance) {
			insClass = instance.getClass();
		}
		final Field[] fs = insClass.getDeclaredFields();
		for (Field f : fs) {
			if (!f.getType().equals(targetClass)) {
				continue;
			}
			if (null == instance && !Modifier.isStatic(f.getModifiers())) {
				// instance が null の場合、static 宣言されいるものに限定。
				continue;
			}
			f.setAccessible(true);	// private でも無視して取る。
			ret.add(f);
		}
		return ret;
	}
	public static List<Object> findPrivateValue(Class<?> insClass, Object instance, Class<?> targetClass) {
		List<Field> fs = findFields(insClass, instance, targetClass);
		List<Object> ret = new ArrayList<Object>();
		for (Field f : fs) {
			try {
				ret.add(f.get(instance));
			} catch (Exception e) {
			}
		}
		return ret;
	}
}
