package net.minecraft.storagebox;

import java.util.List;

import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemOverride;
import net.minecraft.client.renderer.block.model.ItemOverrideList;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.fml.client.FMLClientHandler;

public class ItemOverrideListStorageBox extends ItemOverrideList {

	public ItemOverrideListStorageBox(List<ItemOverride> overridesIn) {
		super(overridesIn);
	}

	@Override
	public IBakedModel handleItemState(IBakedModel originalModel, ItemStack stack, World world,
			EntityLivingBase entity) {
		ItemStack i = ItemStorageBox.peekItemStackAll(stack);
		final ItemModelMesher imm = FMLClientHandler.instance().getClient().getRenderItem().getItemModelMesher();
		if (null == i) {
			return imm.getModelManager().getModel(ItemMeshDefinitionStorageBox._mrl);
		}
		return imm.getItemModel(i);
	}

}
