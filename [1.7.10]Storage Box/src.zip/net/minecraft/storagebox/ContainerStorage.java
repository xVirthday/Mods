package net.minecraft.storagebox;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ContainerStorage extends Container {
	public IInventory storage;

	public ContainerStorage(ItemStack itemstack, InventoryPlayer inventoryplayer, World world) {
		storage = new InventoryStorage(itemstack, inventoryplayer, world);
		addSlotToContainer(new SlotStorage(storage, 0, 12, 35));

		for (int i1 = 0; i1 < 3; i1++) {
			for (int l1 = 0; l1 < 9; l1++) {
				addSlotToContainer(new Slot(inventoryplayer, l1 + i1 * 9 + 9, 8 + l1 * 18, 84 + i1 * 18));
			}
		}

		for (int j1 = 0; j1 < 9; j1++) {
			addSlotToContainer(new Slot(inventoryplayer, j1, 8 + j1 * 18, 142));
		}
	}

	@Override
	public ItemStack slotClick(int slotId, int dragType, ClickType clickTypeIn, EntityPlayer player) {
		//net.minecraftforge.fml.common.FMLLog.log.info("ContainerStorage.slotClick={}, {}, {}", slotId, dragType, clickTypeIn.toString());
		int slotNum = -1;
		if (slotId >= 28 && slotId <= 36 && ClickType.PICKUP == clickTypeIn) {
			slotNum = slotId - 28;
		}
		if (dragType >= 0 && dragType < 9 && ClickType.SWAP == clickTypeIn) {
			slotNum = dragType;
		}
		if (slotNum >= 0) {
			// 数字キー押下での挙動。GUI 表示時に数字キー押下すると StorageBox が複製されるバグへの対応。
			ItemStack is = player.inventory.getStackInSlot(slotNum);
			if (null != is && is.getItem() instanceof ItemStorageBox) {
				return ItemStack.EMPTY;
			}
		}
		// 手に持っているアイテム（つまり GUI を開いている StorageBox）を操作しようとした場合はキャンセル。
		if (slotId >= 28 && slotId <= 36 && player.getHeldItemMainhand() == player.inventory.getStackInSlot(slotId - 28)) {
			return ItemStack.EMPTY;
		}
		//net.minecraftforge.fml.common.FMLLog.log.info("ContainerStorage.slotClick={}, {}, {}(slotNum={})\n", slotId, dragType, clickTypeIn.toString(), slotNum);
		ItemStack b = super.slotClick(slotId, dragType, clickTypeIn, player);
		storage.markDirty();
		return b;
	}

	@Override
	public void onContainerClosed(EntityPlayer entityplayer) {
		storage.markDirty();
		super.onContainerClosed(entityplayer);
	}

	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		return true;
	}

	@Override
	public ItemStack transferStackInSlot(EntityPlayer player, int i) {
		//net.minecraftforge.fml.common.FMLLog.log.info("ContainerStorage.transferStackInSlot={}", i);
		ItemStack itemstack = null;
		Slot slot = (Slot) inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getStack();
			itemstack = itemstack1.copy();

			if (i == 0) {
				if (!mergeItemStack(itemstack1, 1, 37, true)) {
					return ItemStack.EMPTY;
				}
			} else if (i >= 1 && i < 28) {
				final Slot targetSlot = (Slot) inventorySlots.get(0);
				if (!targetSlot.isItemValid(itemstack1)) {
					// それは入れられない。
				} else if (!mergeItemStack(itemstack1, 0, 1, false)) {
					return ItemStack.EMPTY;
				}
			} else if (i >= 28 && i < 37) {
				if (!mergeItemStack(itemstack1, 1, 28, false)) {
					return ItemStack.EMPTY;
				}
			} else if (!mergeItemStack(itemstack1, 1, 37, false)) {
				return ItemStack.EMPTY;
			}

			if (itemstack1.isEmpty()) {
				slot.putStack(ItemStack.EMPTY);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.getCount() != itemstack.getCount()) {
				//slot.onPickupFromSlot(player, itemstack1);
			} else {
				storage.markDirty();
				return ItemStack.EMPTY;
			}
		}

		storage.markDirty();
		return itemstack;
	}

	@Override
	protected boolean mergeItemStack(ItemStack par1ItemStack, int par2, int par3, boolean par4) {
		boolean b = super.mergeItemStack(par1ItemStack, par2, par3, par4);
		storage.markDirty();
		return b;
	}
}
