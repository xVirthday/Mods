package net.minecraft.storagebox;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.internal.FMLNetworkHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.List;

import javax.annotation.Nullable;

public class ItemStorageBox extends Item {
	private static String KEYITEMID = "StorageItem";
	private static String KEYDAMAGE = "StorageDamage";
	private static String KEYSIZE = "StorageSize";
	private static String KEYAUTO = "StorageAuto";
	private static String KEY_ITEM_DATA = "StorageItemData";

    public static int Colors[] =
    {
        0xFFFFFF,	0xEB8844,	0xC354CD,	0x6689D3,
        0xDECF2A,	0x41CD34,	0xD88198,	0x434343,
        0x767676,	0x20E1CD,	0x7B2FBE,	0x253192,
        0x51301A,	0x3B511A,	0xB3312C,	0x1E1B1B
    };

    public ItemStorageBox()
    {
        super();
        setMaxStackSize(1);
        setHasSubtypes(true);
        //setTabToDisplayOn(CreativeTabs.tabMisc);
    }

    @Override
	public Item setUnlocalizedName(String par1Str) {
		//this.setTextureName(par1Str);
		return super.setUnlocalizedName(par1Str);
	}

    @SideOnly(Side.CLIENT)
    @Override
    public boolean hasEffect(ItemStack par1ItemStack)
    {
        ItemStack itemstack = peekItemStackAll(par1ItemStack);

        if (itemstack == null)
        {
            return false;
        }

        return itemstack.getItem().hasEffect(itemstack);
    }

//Forge追加

	@Override
	//public EnumActionResult onItemUse(ItemStack itemstack, EntityPlayer entityplayer, World world, BlockPos pos, EnumHand hand, EnumFacing side, float f, float f1, float f2)
	public EnumActionResult onItemUse(EntityPlayer entityplayer, World world, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
	{
		final ItemStack itemstack = entityplayer.getHeldItem(hand);
		Item sitem = getItem(itemstack);
		//net.minecraftforge.fml.common.FMLLog.info("ItemStorageBox.onItemUse(%s)", Thread.currentThread().toString());

		if (sitem == null) {
			//net.minecraftforge.fml.common.FMLLog.info("ItemStorageBox.onItemUse(%s) sitem==null", Thread.currentThread().toString());
			return super.onItemUse(entityplayer, world, pos, hand, facing, hitX, hitY, hitZ);
		}

		ItemStack sitemstack = getItemStack(itemstack);
		boolean bUse = true;
//*
		if (sitem instanceof ItemBlock) {
			ItemBlock itemBlock = (ItemBlock) sitem;
			if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
				bUse = itemBlock.canPlaceBlockOnSide(world, pos, facing, entityplayer, sitemstack);
			} else {
				bUse = this.canPlaceItemBlockOnSide(world, pos, facing, entityplayer, sitem, sitemstack);
			}
			// bUse = sitemstack.tryPlaceItemIntoWorld(entityplayer, world, i, j, k, l, f, f1, f2);
			// bUse = sitem.onItemUse(sitemstack, entityplayer, world, i, j, k, l, f, f1, f2);
		}
//*
		//FMLLog.info("ItemStorageBox.onItemUse(%s) bUse==%b", Thread.currentThread().toString(), bUse);
		EnumActionResult ret = bUse ? EnumActionResult.SUCCESS : EnumActionResult.PASS;
		if (bUse) {
			// こういう面倒なことをしないとアイテム装備音がしてしまう。
			final int sitemstack_cnt = sitemstack.getCount();
			sitemstack.setCount(0);
			entityplayer.setHeldItem(hand, sitemstack);
			sitemstack.setCount(sitemstack_cnt);

			ret = sitem.onItemUse(/*sitemstack, */entityplayer, world, pos, hand, facing, hitX, hitY, hitZ);
			//net.minecraftforge.fml.common.FMLLog.info("ItemStorageBox.onItemUse=%s", ret);

			// 音がしないように調整しつつ手持ちアイテムを元に戻す。
			final int itemstack_cnt = itemstack.getCount();
			itemstack.setCount(0);
			entityplayer.setHeldItem(hand, itemstack);
			itemstack.setCount(itemstack_cnt);
		}
//*/
		addItemStack(itemstack, sitemstack);
		return ret;
	}

	@Override
	//public ActionResult<ItemStack> onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer, EnumHand hand)
	public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer entityplayer, EnumHand hand)
	{
		final ItemStack itemstack = entityplayer.getHeldItem(hand);
		// NBT を空にせずアイテム情報を取り出す。
		final ItemStack sitemstack = peekItemStack(itemstack);

		if (null != sitemstack && !sitemstack.isEmpty()) {
			entityplayer.setActiveHand(hand);
			// sitemstack を受け付けてくれなくなったので仕方なく使用する瞬間だけ手に持つ。
			// こういう面倒なことをしないとアイテム装備音がしてしまう。
			final int sitemstack_cnt = sitemstack.getCount();
			sitemstack.setCount(0);
			entityplayer.setHeldItem(hand, sitemstack);
			sitemstack.setCount(sitemstack_cnt);
			// アイテムを使用する。
			final ActionResult<ItemStack> tmpStack = sitemstack.getItem().onItemRightClick(/*sitemstack, */world, entityplayer, hand);
			// 音がしないように調整しつつ手持ちアイテムを元に戻す。
			final int itemstack_cnt = itemstack.getCount();
			itemstack.setCount(0);
			entityplayer.setHeldItem(hand, itemstack);
			itemstack.setCount(itemstack_cnt);
			//FMLLog.info("ItemStorageBox.onItemRightClick=%s", tmpStack.getType());
			// ここで NBT タグを空にする。
			getItemStack(itemstack);

			if (null == sitemstack || null == tmpStack || sitemstack.isEmpty()) {
			} else if (EnumActionResult.FAIL == tmpStack.getType()) {
				// 使用できなかった。
				entityplayer.resetActiveHand();
				addItemStack(itemstack, sitemstack);
				return new ActionResult<ItemStack>(tmpStack.getType(), itemstack);
			} else if (sitemstack.isItemEqual(tmpStack.getResult())) {
				// onPlayerStoppedUsingのため、情報引継ぎ
				ItemStack itemUse = null;
				if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
					//itemUse = entityplayer.getItemInUse();
				} else {
					final List<Object> l = mod_StorageBox.findPrivateValue(EntityPlayer.class, entityplayer, ItemStack.class);
					if (1 == l.size()) {
						itemUse = (ItemStack) l.get(0);
					}
				}
				if (itemUse != null && itemUse.getItem() == sitemstack.getItem()) {
					int itemInUseCount = sitemstack.getItem().getMaxItemUseDuration(sitemstack);
					if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
						itemInUseCount = entityplayer.getItemInUseCount();
					}
					//FMLLog.info("ItemStorageBox.onItemRightClick,setItemInUse[%s]", Thread.currentThread().toString());
					//entityplayer.setItemInUse(itemstack, itemInUseCount);
				}
//*/
//				entityplayer.setItemInUse(itemstack, sitem.getMaxItemUseDuration(itemstack));
			} else {
				// バケツ->水バケツ等
				sitemstack.grow(-tmpStack.getResult().getCount());
				dropItem(entityplayer, tmpStack.getResult());
			}

			addItemStack(itemstack, sitemstack);
			return new ActionResult<>(tmpStack.getType(), itemstack);
		} else {
			openInventory(itemstack, entityplayer, world);
		}

		return super.onItemRightClick(world, entityplayer, hand);
	}

	@Override
	public ItemStack onItemUseFinish(ItemStack itemstack, World world, EntityLivingBase entityLiving) {
		Item sitem = getItem(itemstack);

		if (sitem != null) {
			ItemStack sitemstack = getItemStack(itemstack);
			ItemStack tmpStack = sitem.onItemUseFinish(sitemstack, world, entityLiving);
			//FMLLog.info("ItemStorageBox.onItemUseFinish=%s", tmpStack.toString());

			// ポーション→ガラス瓶等
			if (sitemstack != null && !sitemstack.isItemEqual(tmpStack)) {
				dropItem(entityLiving, tmpStack);
			}

			addItemStack(itemstack, sitemstack);
		}

		return super.onItemUseFinish(itemstack, world, entityLiving);
	}

    @Override
    public boolean hitEntity(ItemStack itemstack, EntityLivingBase entityLiving, EntityLivingBase entityLiving2)
    {
        Item sitem = getItem(itemstack);

        if (sitem != null)
        {
            ItemStack sitemstack = getItemStack(itemstack);
            sitem.hitEntity(sitemstack, entityLiving, entityLiving2);
            addItemStack(itemstack, sitemstack);
        }

        return super.hitEntity(itemstack, entityLiving, entityLiving2);
    }

	@Override
	// public boolean onBlockDestroyed(ItemStack itemstack, int i, int j, int k, int l, EntityLiving entityliving)
	public boolean onBlockDestroyed(ItemStack itemstack, World world, IBlockState blockIn, BlockPos pos, EntityLivingBase entityliving) {
		Item sitem = getItem(itemstack);

		if (sitem != null) {
			ItemStack sitemstack = getItemStack(itemstack);
			sitem.onBlockDestroyed(sitemstack, world, blockIn, pos, entityliving);
			addItemStack(itemstack, sitemstack);
		}

		return super.onBlockDestroyed(itemstack, world, blockIn, pos, entityliving);
	}

	@Override
	//public void useItemOnEntity(ItemStack itemstack, EntityLiving entityLiving)
	//public boolean itemInteractionForEntity(ItemStack itemstack, EntityLiving entityLiving) {
	public boolean itemInteractionForEntity(ItemStack itemstack, EntityPlayer entityplayer, EntityLivingBase entityLiving, EnumHand hand) {
		boolean result;
		Item sitem = getItem(itemstack);

		if (sitem != null) {
			ItemStack sitemstack = getItemStack(itemstack);
			result = sitem.itemInteractionForEntity(sitemstack, entityplayer, entityLiving, hand);
			addItemStack(itemstack, sitemstack);
		} else {
			result = super.itemInteractionForEntity(itemstack, entityplayer, entityLiving, hand);
		}

		return result;
	}

	@Override
	public int getMaxItemUseDuration(ItemStack itemstack) {
		Item sitem = getItem(itemstack);

		if (sitem != null) {
			ItemStack sitemstack = peekItemStackAll(itemstack);
			return sitem.getMaxItemUseDuration(sitemstack);
		}

		return super.getMaxItemUseDuration(itemstack);
	}

	@Override
	public EnumAction getItemUseAction(ItemStack itemstack) {
		Item sitem = getItem(itemstack);

		if (sitem != null) {
			ItemStack sitemstack = peekItemStackAll(itemstack);
			return sitem.getItemUseAction(sitemstack);
		}

		return super.getItemUseAction(itemstack);
	}

	@Override
	public void onPlayerStoppedUsing(ItemStack itemstack, World world, EntityLivingBase entityLiving, int timeLeft) {
		Item sItem = getItem(itemstack);

		if (sItem == null) {
			return;
		}

		ItemStack sitemstack = getItemStack(itemstack);
		sItem.onPlayerStoppedUsing(sitemstack, world, entityLiving, timeLeft);
		addItemStack(itemstack, sitemstack);
	}
/*
	@Override
	@SideOnly(Side.CLIENT)
	public int getSpriteNumber() {
		return super.getSpriteNumber();
	}
*/
	/**
	 * 格納されているのが ItemBlock で、その場所に設置できるなら true。それ以外はすべて false。
	 */
	public boolean canPlaceItemBlockOnSide(World par1World, BlockPos pos, EnumFacing side, EntityPlayer par6EntityPlayer, Item sItem, ItemStack par7ItemStack) {
		if (!(sItem instanceof ItemBlock)) {
			return false;
		}
		Block i1 = par1World.getBlockState(pos).getBlock();
		if (i1 == Blocks.SNOW_LAYER) {
			side = EnumFacing.UP;
		} else if (!i1.isReplaceable(par1World, pos)) {
			pos = pos.offset(side);
		}

		return par1World.mayPlace(((ItemBlock)sItem).getBlock(), pos, false, side, null);
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void addInformation(ItemStack itemstack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
		if (!mod_StorageBox.AddName || !mod_StorageBox.AddCount) {
		} else {
			return;
		}

		ItemStack sitemstack = peekItemStackAll(itemstack);
		if (null == sitemstack) {
			return;
		}

		Item sitem = getItem(itemstack);
		if (!mod_StorageBox.AddName) {
			String StorageItemName = "Name : " + sitem.getItemStackDisplayName(sitemstack);
			tooltip.add(StorageItemName);
		}
		if (!mod_StorageBox.AddCount) {
			StringBuilder sb = calcItemNumByUnit(itemstack, false);
			sb.insert(0, "Unit: ");
			tooltip.add(sb.toString());
			tooltip.add("Items: " + sitemstack.getCount());
		}

		tooltip.add("AutoCollect : " + (isAutoCollect(itemstack) ? "ON" : "OFF"));
		tooltip.add("[Information]");
		sitem.addInformation(sitemstack, worldIn, tooltip, flagIn);
	}

	@Override
	public String getItemStackDisplayName(ItemStack itemstack) {
		String ItemName = super.getItemStackDisplayName(itemstack);
/*
		if (isAutoCollect(itemstack)) {
			ItemName += "(AutoCollect)";
		}
*/

		if (mod_StorageBox.AddName || mod_StorageBox.AddCount) {
			ItemStack sitemstack = peekItemStackAll(itemstack);

			if (sitemstack != null) {
				if (mod_StorageBox.AddName) {
					Item sitem = getItem(itemstack);
					ItemName += "/Name:" + sitem.getItemStackDisplayName(sitemstack);
				}

				if (mod_StorageBox.AddCount) {
					ItemName += "/Num:" + calcItemNumByUnit(itemstack, true);
				}
			}
		}

		return ItemName;
	}

	/**
	 * アイテム数を 1LC+2stacks+3items(xxxitems) みたいに返す。
	 */
	private StringBuilder calcItemNumByUnit(ItemStack itemstack, boolean appendItemNum) {
		StringBuilder sb = new StringBuilder("Empty");
		Item sitem = getItem(itemstack);
		if (sitem == null) {
			return sb;
		}
		ItemStack sitemstack = peekItemStackAll(itemstack);
		if (sitemstack == null) {
			return sb;
		}
		sb.setLength(0);
		final int maxstacknum = sitemstack.getMaxStackSize();
		final int LCNUM = mod_StorageBox.largeChestSlotNum * maxstacknum;
		int n = sitemstack.getCount();
		int i = n / LCNUM;
		boolean isHigherUnit = false;
		if (i >= 1) {
			isHigherUnit = true;
			sb.append(i).append("LC");
			n -= i * LCNUM;
		}
		i = n / maxstacknum;
		if (i >= 1) {
			isHigherUnit = true;
			if (sb.length() >= 1) {
				sb.append('+');
			}
			sb.append(i).append("stacks");
			n -= i * maxstacknum;
		}
		if (n >= 1) {
			if (sb.length() >= 1) {
				sb.append('+');
			}
			sb.append(n).append("items");
		}
		if (isHigherUnit && appendItemNum) {
			sb.append('(').append(sitemstack.getCount()).append("items)");
		}
		return sb;
	}
	/**
	 * アイテム情報表示
	 *
	 * @param itemstack
	 *            storagebox
	 */
	@SideOnly(Side.CLIENT)
	public void displayItemInfo(ItemStack itemstack) {
		StringBuilder sb = calcItemNumByUnit(itemstack, true);
		do {
			Item sitem = getItem(itemstack);
			if (sitem == null) {
				break;
			}
			ItemStack sitemstack = peekItemStackAll(itemstack);
			if (sitemstack == null || sitemstack.isEmpty()) {
				break;
			}
			sb.insert(0, '/').insert(0, sitem.getItemStackDisplayName(sitemstack));
		} while(false);

		final String s = sb.toString();
		final Minecraft mc = FMLClientHandler.instance().getClient();
		int w = mc.displayWidth;
		int h = mc.displayHeight;
		ScaledResolution scaledresolution = new ScaledResolution(mc);
		w = (scaledresolution.getScaledWidth() - mc.fontRenderer.getStringWidth(s)) / 2;
		h = scaledresolution.getScaledHeight();
		mc.fontRenderer.drawString(s, w, h - 60 - mod_StorageBox.Position, mod_StorageBox.Color);
		//FMLLog.info(s);
	}

	/**
	 * チェスト連携機能 チェストへ格納する
	 *
	 * @param itemstack
	 *            プレイヤーが現在手に持っているアイテム
	 * @param Slots
	 *            GUIの表示スロット一覧
	 */
	@SuppressWarnings("rawtypes")
	public void dropToChest(ItemStack itemstack, List Slots, boolean onlyOneStack) {
		ItemStack sitemstack = peekItemStackAll(itemstack);

		if (sitemstack == null || sitemstack.isEmpty()) {
			return;
		}

		int size = sitemstack.getCount();
		IInventory iinventory = ((Slot) Slots.get(0)).inventory;
		int slotsize = iinventory.getSizeInventory();
		Slot slot = null;

		for (int i = 0; i < slotsize; i++) {
			ItemStack itemstack2 = iinventory.getStackInSlot(i);

			if (i < Slots.size()) {
				slot = (Slot) Slots.get(i);
			}

			if (slot == null) {
				continue;
			}

			if (!slot.isItemValid(itemstack2)) {
				continue;
			}

			boolean blAddItem = false;
			if (itemstack2 == null || itemstack2.isEmpty()) {
				ItemStack itemstack3 = sitemstack.copy();

				if (size > sitemstack.getMaxStackSize()) {
					itemstack3.setCount(sitemstack.getMaxStackSize());
					size -= itemstack3.getCount();
				} else {
					itemstack3.setCount(size);
					size = 0;
				}

				blAddItem = true;
				iinventory.setInventorySlotContents(i, itemstack3.copy());
				// }else if (ItemStack.areItemStacksEqual(sitemstack, itemstack2)
				// && itemstack2.stackSize < itemstack2.getMaxStackSize()){
			} else if (sitemstack.isItemEqual(itemstack2)
					&& itemstack2.getCount() < itemstack2.getMaxStackSize()) {
				blAddItem = true;
				if (size > sitemstack.getMaxStackSize() - itemstack2.getCount()) {
					size -= sitemstack.getMaxStackSize() - itemstack2.getCount();
					itemstack2.setCount(sitemstack.getMaxStackSize());
				} else {
					itemstack2.grow(size);
					size = 0;
				}
			}

			if (size == 0) {
				break;
			}
			if (onlyOneStack && blAddItem) {
				break;
			}
		}

		iinventory.markDirty();
		sitemstack.grow(-size);
		removeItemStack(itemstack, sitemstack);
	}

	/**
	 * チェスト連携機能 チェストから取り出す
	 *
	 * @param itemstack
	 *            storagebox
	 * @param Slots
	 *            GUIの表示スロット一覧
	 */
	@SuppressWarnings("rawtypes")
	public void storageFromChest(EntityPlayer entityplayer, ItemStack itemstack, List Slots) {
		ItemStack sitemstack = peekItemStackAll(itemstack);

		if (sitemstack == null || sitemstack.isEmpty()) {
			return;
		}

		int size = 0;// sitemstack.stackSize;
		IInventory iinventory = ((Slot) Slots.get(0)).inventory;
		int slotsize = iinventory.getSizeInventory();
		Slot slot = null;

		for (int i = 0; i < slotsize; i++) {
			ItemStack itemstack2 = iinventory.getStackInSlot(i);

			if (itemstack2 == null || itemstack2.isEmpty()) {
				continue;
			}

			if (i < Slots.size()) {
				slot = (Slot) Slots.get(i);
			}

			if (slot == null) {
				continue;
			}

			if (!slot.isItemValid(itemstack2)) {
				continue;
			}

			if (sitemstack.isItemEqual(itemstack2)) {
				slot.onTake(entityplayer, itemstack2);

				if (itemstack2.getCount() > 0) {
					size += itemstack2.getCount();
					iinventory.setInventorySlotContents(i, ItemStack.EMPTY);
				}
			}
		}

		iinventory.markDirty();
		sitemstack.setCount(size);
		addItemStack(itemstack, sitemstack);
    }

	/**
	 * [L]キー押下時
	 *
	 * @param isShiftKey boolean シフトキー押下時に true
	 * @param player
	 */
	public void keyboardEvent(boolean isShiftKey, EntityPlayer player) {
		ItemStack CurrentStack = player.inventory.getCurrentItem();

		if (CurrentStack != null) {
			Item CurrentItem = CurrentStack.getItem();

			if (CurrentItem instanceof ItemStorageBox) {
				if (isShiftKey) {
					dropCurrentItem(CurrentStack, player);
				} else {
					storageCurrentItem(CurrentStack, player);
				}
				return;
			}
		}

		if (!isShiftKey) {
			for (ItemStack i : player.inventory.mainInventory) {
				if (i != null && i.getItem() instanceof ItemStorageBox && !i.isEmpty()) {
					Item sitem = getItem(i);
					if (sitem != null) {
						storageCurrentItem(i, player);
					}
				}
			}
		}
	}

	/**
	 * [L]キー押下時のアイテム収納処理
	 *
	 * @param itemstack
	 *            storagebox
	 * @param entityplayer
	 */
	public void storageCurrentItem(ItemStack itemstack, EntityPlayer entityplayer) {
		// World world = mc.world;
		// EntityPlayer entityplayer = mc.player;
		World world = entityplayer.world;
		// 収納アイテムがない場合、選択画面を開く
		Item sitem = getItem(itemstack);

		if (sitem == null) {
			openInventory(itemstack, entityplayer, world);
		} else {
			storageItem(itemstack, entityplayer);
		}
	}

	/**
	 * [L]キー押下時のアイテムドロップ処理
	 *
	 * @param itemstack
	 *            storagebox
	 * @param entityplayer
	 */
	public void dropCurrentItem(ItemStack itemstack, EntityPlayer entityplayer) {
		dropCurrentItem(itemstack, entityplayer, 0);
	}

	/**
	 * [L]キー押下時のアイテムドロップ処理
	 *
	 * @param itemstack
	 *            storagebox
	 * @param entityplayer
	 */
	public void dropCurrentItem(ItemStack itemstack, EntityPlayer entityplayer, int maxnum) {
		ItemStack sitemstack = getItemStack(itemstack, maxnum);

		if (sitemstack == null) {
			return;
		}

		do {
			if (maxnum >= 1) {
				int n = entityplayer.inventory.getFirstEmptyStack();
				if (n >= 0) {
					entityplayer.inventory.setInventorySlotContents(n, sitemstack);
					sitemstack = null;
					break;
				}
			}
			if (entityplayer.inventory.addItemStackToInventory(sitemstack)) {
				entityplayer.inventory.markDirty();
			}
			break;
		} while(false);
		if (null != sitemstack) {
			if (sitemstack.getCount() > 0) {
				entityplayer.dropItem(sitemstack.copy(), false);
			}
		}
		// addItemStack(itemstack, sitemstack);
	}

	/**
	 * 収納アイテム選択GUIの表示
	 *
	 * @param itemstack
	 *            storagebox
	 * @param entityplayer
	 *            実行ユーザー
	 * @param world
	 *            実行ワールド
	 */
	private void openInventory(ItemStack itemstack, EntityPlayer entityplayer, World world) {
/*
		if(world.isRemote){
			ModLoader.openGUI(entityplayer, new GuiStorage(entityplayer.getCurrentEquippedItem() , entityplayer.inventory,world));
		}else{
			ModLoader.serverOpenWindow((EntityPlayerMP) entityplayer, new ContainerStorage(entityplayer.getCurrentEquippedItem(), entityplayer.inventory,world), 21, entityplayer.inventory.currentItem, 0, 0);
		}
*/
		if (world.isRemote) {
			// ModLoader.serverOpenWindowでクライアント側も開くため不要
		} else {
			//cpw.mods.fml.common.FMLLog.info("openInventory , FMLNetworkHandler.openGui");
			FMLNetworkHandler.openGui(entityplayer, mod_StorageBox._instance, mod_StorageBox.containerID, world
					, entityplayer.inventory.offHandInventory.get(0) == itemstack ? -1 : entityplayer.inventory.currentItem, 0, 0);
/*
			ModLoader.serverOpenWindow((EntityPlayerMP) entityplayer,
					new ContainerStorage(entityplayer.getCurrentEquippedItem(), entityplayer.inventory, world),
					mod_StorageBox.containerID,
					entityplayer.inventory.currentItem, 0, 0);
*/
		}
    }

	/**
	 * アイテム収納処理
	 *
	 * @param itemstack
	 *            収納対象アイテム
	 * @param entityplayer
	 *            実行ユーザー
	 */
	private void storageItem(ItemStack itemstack, EntityPlayer entityplayer) {
		ItemStack sitemstack = peekItemStackAll(itemstack);

		if (sitemstack == null) {
			return;
		}

		int size = 0;// sitemstack.stackSize;
		InventoryPlayer inventory = entityplayer.inventory;
		final List<ItemStack> aitemstacks = inventory.mainInventory;

		for (int k = 0; k < aitemstacks.size(); k++) {
			// if (aitemstacks[k] != null && ItemStack.areItemStacksEqual(sitemstack, aitemstacks[k]))
			if (aitemstacks.get(k) != null && sitemstack.isItemEqual(aitemstacks.get(k))) {
				size += aitemstacks.get(k).getCount();
				aitemstacks.set(k, ItemStack.EMPTY);
			}
		}

		sitemstack.setCount(size);
		addItemStack(itemstack, sitemstack);
	}

	/**
	 * アイテムのドロップ処理
	 *
	 * @param entityplayer
	 *            実行ユーザー
	 * @param itemstack
	 *            ドロップするアイテム
	 */
	private void dropItem(EntityLivingBase entityplayer, ItemStack itemstack) {
		// プレイヤーのみ実行可能
		if (isPlayer(entityplayer)) {
			EntityItem ei = new EntityItem(entityplayer.world, entityplayer.posX, entityplayer.posY, entityplayer.posZ, itemstack.copy());
			ei.setNoPickupDelay();
			entityplayer.world.spawnEntity(ei);
			itemstack.setCount(0);
		}
	}

	/**
	 * プレイヤー判定
	 *
	 * @param entityplayer
	 *            実行ユーザー
	 * @return プレイヤーであるか否か
	 */
	private boolean isPlayer(EntityLivingBase entityplayer) {
		if (!(entityplayer instanceof EntityPlayerMP)) {
			return false;
		}
		for (Object o : FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayers()) {
			if (null != o && o instanceof EntityPlayer) {
			} else {
				continue;
			}
			final EntityPlayer ep = (EntityPlayer) o;
			if (ep.getEntityId() == entityplayer.getEntityId()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * NBTからItemインスタンスを生成して返す
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @return Itemインスタンス
	 */
	public static Item getItem(ItemStack itemstack) {
		ItemStack i = readStoredItemStack(itemstack);
		if (null != i) {
			return i.getItem();
		}
		int ItemID = getItemData(itemstack, KEYITEMID);

		if (ItemID == 0) {
			return null;
		}

		int size = getItemData(itemstack, KEYSIZE);

		if (size > 0) {
			return Item.getItemById(ItemID);
		} else {
			return null;
		}
	}
	/**
	 * storagebox の ItemStack から格納アイテムを読みだす。
	 * 読み出された ItemStack の stacksize は byte なので信じないこと。
	 * @param storagebox
	 * @return 格納されているアイテム
	 */
	private static ItemStack readStoredItemStack(ItemStack storagebox) {
		ItemStack result = null;
		do {
			NBTTagCompound tagcom = storagebox.getTagCompound();
			if (null == tagcom) {
				break;
			}
			tagcom = tagcom.getCompoundTag(KEY_ITEM_DATA);
			if (null == tagcom) {
				break;
			}
			if (tagcom.hasNoTags()) {
				break;
			}
			result = new ItemStack(tagcom);
			result.setCount(1);
			return result;
		} while (false);
		return null;
	}

	/**
	 * NBTからItemStackインスタンスを生成して返す。 NBTデータの更新を行う。
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @return ItemStackインスタンス
	 */
	public static ItemStack getItemStack(ItemStack itemstack) {
		return getItemStack(itemstack, 0);
	}

	/**
	 * NBTからItemStackインスタンスを生成して返す。 NBTデータの更新を行う。
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @param maxnum
	 *            取得数
	 * @return ItemStackインスタンス
	 */
	public static ItemStack getItemStack(ItemStack itemstack, int maxnum) {
		ItemStack result = peekItemStack(itemstack, maxnum);

		if (result == null) {
			return null;
		}

		removeItemStack(itemstack, result);
		return result;
	}

	/**
	 * NBTからItemStackインスタンスを生成して返す。 NBTデータの更新を行う。
	 *
	 * @param itemstack
	 *            NBT設定先
	 * @param newstack
	 *            設定対象
	 */
	public static void setItemStack(ItemStack itemstack, ItemStack newstack) {
		if (ItemStack.EMPTY == itemstack) {
			return;
		}
		if (newstack == null || ItemStack.EMPTY == newstack) {
			setItemData(itemstack, KEY_ITEM_DATA, null);
		} else {
			NBTTagCompound tag = new NBTTagCompound();
			newstack.writeToNBT(tag);
			setItemData(itemstack, KEY_ITEM_DATA, tag);
			setItemData(itemstack, KEYSIZE, newstack.getCount());
		}
	}

	/**
	 * NBTからItemStackインスタンス(スタック上限)を生成して返す。 NBTデータの更新を行わない。
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @return ItemStackインスタンス
	 */
	public static ItemStack peekItemStack(ItemStack itemstack) {
		return peekItemStack(itemstack, 0);
	}
	/**
	 * NBTからItemStackインスタンス(指定個数を上限とする)を生成して返す。 NBTデータの更新を行わない。
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @param maxnum 上限個数。0 以下の場合は stacklimit。
	 * @return ItemStackインスタンス
	 */
	public static ItemStack peekItemStack(ItemStack itemstack, int maxnum) {
		ItemStack result = peekItemStackAll(itemstack);

		if (result == null) {
			return null;
		}
		if (maxnum <= 0) {
			maxnum = result.getMaxStackSize();
		}

		if (maxnum >= 1 && result.getCount() > maxnum) {
			result.setCount(maxnum);
		}

		return result;
	}

	/**
	 * NBTからItemStackインスタンス(全スタック)を生成して返す。 NBTデータの更新を行わない。
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @return ItemStackインスタンス
	 */
	public static ItemStack peekItemStackAll(ItemStack itemstack) {
		ItemStack result = readStoredItemStack(itemstack);
		Item item = null;
		if (null == result) {
			item = getItem(itemstack);
			if (item == null) {
				return null;
			}
		}

		int size = getItemData(itemstack, KEYSIZE);

		if (size > 0) {
			if (null != result) {
				result.setCount(size);
			} else {
				int damage = getItemData(itemstack, KEYDAMAGE);
				result = new ItemStack(item, size, damage);
				setItemStack(itemstack, result);
				net.minecraftforge.fml.common.FMLLog.info("StorageBox tag convert.[%s]", result.toString());
			}
		} else {
			setItemStack(itemstack, null);
		}

		return result;
	}

	/**
	 * NBTのスタックサイズに加算する
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @param addstack
	 *            加算する対象
	 * @return ItemStackインスタンス
	 */
	public static void addItemStack(ItemStack itemstack, ItemStack addstack) {
		if (null == addstack || addstack.isEmpty()) {
			return;
		}
		ItemStack itemstackAll = peekItemStackAll(itemstack);

		if (itemstackAll == null || itemstackAll.isEmpty()) {
			setItemStack(itemstack, addstack);
			addstack = null;
		} else {
			// itemstackの一致確認
			if (itemstackAll.isItemEqual(addstack)) {
				// if(ItemStack.areItemStacksEqual(addstack, itemstackAll)){
				itemstackAll.grow(addstack.getCount());
				addstack = null;
				setItemStack(itemstack, itemstackAll);
			}
		}
	}

	/**
	 * NBTのスタックサイズを減算する
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @param removestack
	 *            減算する対象
	 * @return 減算結果
	 */
	public static ItemStack removeItemStack(ItemStack itemstack, ItemStack removestack) {
		ItemStack itemstackAll = peekItemStackAll(itemstack);

		// itemstackの一致確認
		// if(itemstackAll != null && ItemStack.areItemStacksEqual(removestack,
		// itemstackAll) ){
		if (itemstackAll != null && itemstackAll.isItemEqual(removestack)) {
			if (removestack.getCount() > itemstackAll.getCount()) {
				removestack.grow(-itemstackAll.getCount());
				itemstackAll = null;
			} else {
				itemstackAll.grow(-removestack.getCount());
				removestack = null;
			}

			setItemStack(itemstack, itemstackAll);
		}

		return removestack;
	}

	/**
	 * NBTからデータを取得して返す
	 *
	 * @param itemstack
	 *            NBT取得元
	 * @param Key
	 *            取得キー
	 * @return 取得したデータ
	 */
	private static int getItemData(ItemStack itemstack, String Key) {
		int ItemData = 0;
		NBTTagCompound nbttagcompound = itemstack.getTagCompound();

		if (nbttagcompound != null) {
			ItemData = nbttagcompound.getInteger(Key);
		}

		return ItemData;
	}

	/**
	 * NBTにデータを設定する
	 *
	 * @param itemstack
	 *            NBT設定先
	 * @param Key
	 *            設定キー
	 * @param ItemData
	 *            設定データ
	 */
	private static void setItemData(ItemStack itemstack, String Key, int ItemData) {
		NBTTagCompound nbttagcompound = itemstack.getTagCompound();

		if (nbttagcompound == null) {
			nbttagcompound = new NBTTagCompound();
		}

		nbttagcompound.setInteger(Key, (int) ItemData);
		itemstack.setTagCompound(nbttagcompound);
	}
	private static void setItemData(ItemStack itemstack, String Key, NBTTagCompound tag) {
		NBTTagCompound nbttagcompound = itemstack.getTagCompound();

		if (nbttagcompound == null) {
			nbttagcompound = new NBTTagCompound();
		}

		if (null != tag) {
			nbttagcompound.setTag(Key, tag);
		} else {
			nbttagcompound.removeTag(Key);
		}
		itemstack.setTagCompound(nbttagcompound);
	}

    /**
     * 自動回収機能が有効であるか
     *
     * @param	itemstack	NBT取得先
    */
    public static boolean isAutoCollect(ItemStack itemstack)
    {
        return getItemData(itemstack, KEYAUTO) == 0;
    }

    /**
     * 自動回収機能をON/OFF切り替え
     *
     * @param	itemstack	NBT設定先
    */
    public static void changeAutoCollect(ItemStack itemstack)
    {
        int value = isAutoCollect(itemstack) ? 1 : 0;
        setItemData(itemstack, KEYAUTO, value);
    }
}
