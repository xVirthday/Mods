package net.minecraft.storagebox;

import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraftforge.client.event.ModelBakeEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class EventModelBake {
	private static final IBakedModel _model = new ItemModelStorageBox();
	@SubscribeEvent
	public void onModelBake(ModelBakeEvent ev) {
		//Object o = ev.modelRegistry.getObject(mod_StorageBox._mrl);
		//net.minecraftforge.fml.common.FMLLog.info("EventModelBake.onModelBake=" + o);
		ev.getModelRegistry().putObject(ItemMeshDefinitionStorageBox._mrlMeshDef, _model);
	}
}
