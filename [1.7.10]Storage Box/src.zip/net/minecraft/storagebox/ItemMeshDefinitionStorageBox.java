package net.minecraft.storagebox;

import net.minecraft.client.renderer.ItemMeshDefinition;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ItemMeshDefinitionStorageBox implements ItemMeshDefinition {
	static final ModelResourceLocation _mrl = new ModelResourceLocation(mod_StorageBox.MOD_ID + ":storagebox", "inventory");
	static final ModelResourceLocation _mrlMeshDef = new ModelResourceLocation(mod_StorageBox.MOD_ID + ":storagebox_mesh_def", "inventory");
	@Override
	public ModelResourceLocation getModelLocation(ItemStack stack) {
		return _mrlMeshDef;
	}
}
