package net.minecraft.storagebox;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.Level;

import net.minecraft.block.BlockEnderChest;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class EventHooks
{
	@SubscribeEvent
	public void onItemPickup(EntityItemPickupEvent event) {
		final EntityPlayer player = event.getEntityPlayer();
		final EntityItem item = event.getItem();
		final int size = item.getItem().getCount();

		if (pickupItem(player, item.getItem())) {
			item.setItem(ItemStack.EMPTY);
			event.setCanceled(true);
			player.world.playSound(event.getItem().posX
					, event.getItem().posY
					, event.getItem().posZ
					, SoundEvents.ENTITY_ITEM_PICKUP
					, SoundCategory.PLAYERS
					, 0.2F, (float) (((Math.random() - Math.random()) * 0.7 + 1) * 2), false);
			player.onItemPickup(item, size);
		}
	}

	/**
	 * StorageBox に拾ったアイテムを追加する。
	 * @param is StorageBox の ItemStack
	 * @param pickupitem 拾ったアイテム
	 * @return 格納できたら true。
	 */
	private boolean add(final ItemStack is, final ItemStack pickupitem) {
		final ItemStack storageStack = ItemStorageBox.peekItemStackAll(is);
		if (storageStack != null && pickupitem.isItemEqual(storageStack)) {
			ItemStorageBox.addItemStack(is, pickupitem);
			pickupitem.setCount(0);
			return true;
		}
		return false;
	}
	/**
	 * アイテムを拾った時に呼ばれる。そのアイテムを格納できるなら格納する。
	 * @param player 拾ったプレイヤー
	 * @param item 拾ったアイテム
	 * @return 拾ったアイテムを StorageBox に格納した場合 true。格納できなかった場合は false。
	 */
	private boolean pickupItem(EntityPlayer player, ItemStack item) {
		// 収納アイテム設定 GUI を開いている間は、StorageBox への自動収納をしない。
		if (player instanceof EntityPlayerMP) {
			EntityPlayerMP epmp = (EntityPlayerMP) player;
			if (null != epmp.openContainer && epmp.openContainer instanceof ContainerStorage) {
				return false;
			}
		}
		final List<ItemStack> inventory = new ArrayList<>();
		inventory.addAll(player.inventory.mainInventory);
		if (null != player.getHeldItemOffhand()) {
			inventory.add(player.getHeldItemOffhand());
		}
		return pickupItem(player, inventory, item);
	}
	/**
	 * IInventory から全スロットの ItemStack を配列で取り出す。
	 * @param inv
	 * @return
	 */
	private ItemStack[] getItemStackArrayFromIInventory(final IInventory inv) {
		if (null == inv) {
			return null;
		}
		final ItemStack[] ret = new ItemStack[inv.getSizeInventory()];
		for (int i = 0; i < ret.length; ++i) {
			ret[i] = inv.getStackInSlot(i);
		}
		return ret;
	}
	private boolean pickupItem(final EntityPlayer ep, final ItemStack[] inv, final ItemStack pickupitem) {
		return pickupItem(ep, Arrays.asList(inv), pickupitem);
	}
	/**
	 * ItemStack 配列に対して、拾ったアイテムに対応する StorageBox を探して格納する。
	 * @param ep プレイヤー
	 * @param inv インベントリ
	 * @param pickupitem 拾ったアイテム
	 * @return 格納できたら true。できなかったら false。
	 */
	private boolean pickupItem(final EntityPlayer ep, final List<ItemStack> inv, final ItemStack pickupitem) {
		if (null == inv) {
			return false;
		}
		for (final ItemStack is : inv) {
			if (null == is) {
				continue;
			}
			if (is.getItem() instanceof ItemStorageBox && ItemStorageBox.isAutoCollect(is)) {
				if (add(is, pickupitem)) {
					return true;
				}
			}
			// 他のバッグ系への対応。
			final IInventory inv2 = getIInventoryFromBrad16840Backpack(ep, is);
			if (null != inv2) {
				final ItemStack[] inv2ItemStack = getItemStackArrayFromIInventory(inv2);
				if (pickupItem(ep, inv2ItemStack, pickupitem)) {
					// backpack の中の StorageBox で格納できた。
					return true;
				}
			}
			// 手持ちのエンダーチェスト内の StorageBox への対応。
			if (mod_StorageBox.exploreEnderChest
					&& is.getItem() instanceof ItemBlock
					&& ((ItemBlock) is.getItem()).getBlock() instanceof BlockEnderChest) {
				// プレイヤーのインベントリ内にエンダーチェストがあった。
				final ItemStack[] inv2ItemStack = getItemStackArrayFromIInventory(ep.getInventoryEnderChest());
				if (pickupItem(ep, inv2ItemStack, pickupitem)) {
					// エンダーチェストの中の StorageBox で格納できた。
					return true;
				}
			}
			// シュルカーボックス対応。
			do {
				if (!mod_StorageBox.exploreEnderChest) {
					break;
				}
				if (is.getItem() instanceof ItemShulkerBox) {
				} else {
					break;
				}
				// プレイヤーのインベントリ内にシュルカーボックスがあった。
				final String tagName = "BlockEntityTag";	// 本当はマジックナンバーを書きたくないが、外部化されていないので仕方なく。
				final NBTTagCompound tc1 = is.getTagCompound();
				if (null == tc1) {
					break;
				}
				final NBTTagCompound tc2 = tc1.getCompoundTag(tagName);
				if (null == tc2 || tc2.getKeySet().isEmpty()) {
					break;
				}
				// TileEntity に読み取らせる。
				final TileEntityShulkerBox tesb = new TileEntityShulkerBox();
				tesb.loadFromNbt(tc2);
				// private メンバの items を取りだす。
				final List<Object> lItemsField = mod_StorageBox.findPrivateValue(tesb.getClass(), tesb, NonNullList.class);
				if (lItemsField.isEmpty()) {
					System.out.println("No items field in TileEntityShulkerBox.");
					break;
				}
				// 格納してみる。
				@SuppressWarnings("unchecked")
				final NonNullList<ItemStack> items = (NonNullList<ItemStack>) lItemsField.get(0);
				final ItemStack[] inv2ItemStack = items.toArray(new ItemStack[1]);
				if (pickupItem(ep, inv2ItemStack, pickupitem)) {
					// シュルカーボックスの中の StorageBox で格納できた。
					return true;
				}
			} while (false);
		}
		return false;
	}

	private static final String classNameBrad16840Backpack			= "brad16840.backpacks.items.Backpack";
	private static final String classNameBrad16840QuantumBackpack	= "brad16840.backpacks.items.QuantumBackpack";
	/**
	 * http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1291844-backpacks-by-brad16840
	 * Brad16840氏のBackpackであればtrue
	 * @param t
	 * @return
	 */
	public static boolean isBrad16840Backpack(Item t) {
		if (null == t) {
			return false;
		}
		final Class<?> c = t.getClass();
		String s = null == c ? null : c.getName();
		if (null == s) {
			return false;
		}
		if (s.indexOf(classNameBrad16840Backpack) >= 0) {
			return true;
		}
		if (s.indexOf(classNameBrad16840QuantumBackpack) >= 0) {
			return true;
		}
		return false;
	}

	private static boolean isInitBrad16840 = false;
	private static Method mUniqueItemGetIdentifier = null;
	private static Method mCreateInventory = null;
	private static Method mGetInfo = null;
	private static Method mGetChest = null;
	private static Method mGetInventory = null;
	private static Field fBackpackId = null;
	private static Item backpack = null;
	/**
	 * Brad16840氏のBackpackから IInventory を取り出す。
	 * @param ep
	 * @param is
	 * @return
	 */
	public static IInventory getIInventoryFromBrad16840Backpack(final EntityPlayer ep, final ItemStack is) {
		if (!isBrad16840Backpack(is.getItem())) {
			return null;
		}
		// 必要なメソッド類を取り出す。
		if (!isInitBrad16840) {
			isInitBrad16840 = true;
			Class<?> clsItem = null;
			try {
				clsItem = Class.forName(classNameBrad16840Backpack);
			} catch (ClassNotFoundException e1) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no %s Class.", classNameBrad16840Backpack);
				return null;
			}
			try {
				mUniqueItemGetIdentifier = clsItem.getMethod("getIdentifier", ItemStack.class);
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no UniqueItem.getIdentifier method.");
				return null;
			}

			try {
				clsItem = Class.forName(classNameBrad16840QuantumBackpack);
			} catch (ClassNotFoundException e1) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no %s Class.", classNameBrad16840QuantumBackpack);
				return null;
			}
			try {
				mGetInfo = clsItem.getMethod("getInfo", ItemStack.class);
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no QuantumBackpack.getInfo method.");
				return null;
			}

			String s = "brad16840.backpacks.blocks.QuantumChestTileEntity$VirtualQuantumChest";
			try {
				clsItem = Class.forName(s);
			} catch (ClassNotFoundException e1) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no %s Class.", s);
				return null;
			}
			try {
				mGetChest = clsItem.getMethod("getChest", World.class, String.class);
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no VirtualQuantumChest.getChest method.");
				return null;
			}
			try {
				fBackpackId = clsItem.getField("backpackId");
			} catch (Exception e1) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no VirtualQuantumChest.backpackId field.");
				return null;
			}

			Class<?> clsUniqueItemInventory = null;
			try {
				clsUniqueItemInventory = Class.forName("brad16840.common.UniqueItemInventory");
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no UniqueItemInventory class.");
				return null;
			}
			Method[] ms = clsUniqueItemInventory.getMethods();
			for (Method m : ms) {
				final Parameter[] ps = m.getParameters();
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "UniqueItemInventory.%s(%d)", m.getName(), ps.length);
				if (m.getName().equalsIgnoreCase("createInventory") && ps.length == 3) {
					mCreateInventory = m;
				}
				if (m.getName().equalsIgnoreCase("getInventory") && ps.length == 2) {
					mGetInventory = m;
				}
			}
			if (null == mCreateInventory) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no UniqueItemInventory.createInventory method.");
				return null;
			}
			if (null == mGetInventory) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no UniqueItemInventory.getInventory method.");
				return null;
			}

			final Class<?> clsCommon;
			try {
				clsCommon = Class.forName("brad16840.common.Common");
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no brad16840.common.Common class.");
				return null;
			}
			for (Field f : clsCommon.getFields()) {
				if (!f.getName().equalsIgnoreCase("backpack")) {
					continue;
				}
				try {
					backpack = (Item) f.get(null);
				} catch (Exception e) {
					net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "failed brad16840.common.Common.backpack field get.");
					return null;
				}
			}
			if (null == backpack) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "no brad16840.common.Common.backpack field.");
				return null;
			}
			net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "brad16840 Backpacks! method get complete.");
		}
		if (null == mUniqueItemGetIdentifier || null == mGetInfo) {
			return null;
		}
		if (null == mCreateInventory) {
			return null;
		}
		if (null == backpack) {
			return null;
		}

		String guid = null;
		IInventory iinv = null;
		if (is.getItem().getClass().getName().equalsIgnoreCase(classNameBrad16840QuantumBackpack)) {
			// Quantum Backpack の場合。まず chestId を得る。
			final String chestId;
			try {
				chestId = (String) mGetInfo.invoke(null, is);
			} catch (Exception e3) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "failed QuantumBackpack.mGetInfo invoke.");
				return null;
			}

			// VirtualQuantumChest の実体を得る。
			final Object vqc;
			try {
				vqc = mGetChest.invoke(null, ep.world, chestId);
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "failed VirtualQuantumChest.getChest method.");
				return null;
			}

			// VirtualQuantumChest に入っている guid を取り出す。
			try {
				guid = (String) fBackpackId.get(vqc);
			} catch (Exception e1) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "failed VirtualQuantumChest.backpackId field get.");
				return null;
			}
			net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "VirtualQuantumChest.backpackId=%s", guid);

			// guid に対応する IInventory を取り出す。
			try {
				iinv = (IInventory) mGetInventory.invoke(null, ep, guid);
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "failed UniqueItemInventory.getInventory invoke.");
				return null;
			}
		} else {
			// 通常の Backpack の場合。
			try {
				guid = (String) mUniqueItemGetIdentifier.invoke(null, is);
			} catch (Exception e1) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "failed UniqueItem.getIdentifier method.");
				return null;
			}
			net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "UniqueItem.getIdentifier=%s", guid);

			try {
				iinv = (IInventory) mCreateInventory.invoke(null, backpack, ep, guid);
			} catch (Exception e) {
				net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "failed UniqueItemInventory.createInventory method.");
				return null;
			}
		}

		if (null == iinv) {
			net.minecraftforge.fml.common.FMLLog.log.printf(Level.INFO, "iinv = null.");
		}
		return iinv;
	}
}
